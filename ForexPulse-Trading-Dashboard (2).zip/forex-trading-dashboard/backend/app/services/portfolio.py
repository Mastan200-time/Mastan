"""
Simulated portfolio tracker service.
Manages virtual trades with a paper trading balance.
"""
import json
import os
import time
from typing import List, Dict, Optional
from datetime import datetime
from .forex_data import get_forex_data

PORTFOLIO_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "portfolio_data.json")
INITIAL_BALANCE = 10000.0


def _load_portfolio() -> Dict:
    """Load portfolio from file or create default."""
    if os.path.exists(PORTFOLIO_FILE):
        try:
            with open(PORTFOLIO_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass

    return {
        "balance": INITIAL_BALANCE,
        "initial_balance": INITIAL_BALANCE,
        "positions": [],
        "trade_history": [],
        "next_id": 1,
    }


def _save_portfolio(portfolio: Dict):
    """Save portfolio to file."""
    with open(PORTFOLIO_FILE, "w") as f:
        json.dump(portfolio, f, indent=2, ensure_ascii=False)


def get_portfolio_summary() -> Dict:
    """Get current portfolio summary with live P&L."""
    portfolio = _load_portfolio()
    positions_with_pnl = []

    for pos in portfolio["positions"]:
        df = get_forex_data(pos["pair"], period="1d", interval="1h")
        current_price = float(df["Close"].iloc[-1]) if df is not None and len(df) > 0 else pos["entry_price"]

        if pos["type"] == "BUY":
            pnl = (current_price - pos["entry_price"]) * pos["quantity"]
        else:
            pnl = (pos["entry_price"] - current_price) * pos["quantity"]

        pnl_pct = (pnl / (pos["entry_price"] * pos["quantity"])) * 100

        positions_with_pnl.append({
            "id": pos["id"],
            "pair": pos["pair"],
            "type": pos["type"],
            "entry_price": pos["entry_price"],
            "current_price": round(current_price, 5),
            "quantity": pos["quantity"],
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl_pct, 2),
            "timestamp": pos["timestamp"],
        })

    total_unrealized_pnl = sum(p["pnl"] for p in positions_with_pnl)
    realized_pnl = sum(t.get("pnl", 0) for t in portfolio["trade_history"])
    total_pnl = realized_pnl + total_unrealized_pnl

    equity = portfolio["balance"] + total_unrealized_pnl
    total_pnl_pct = ((equity - portfolio["initial_balance"]) / portfolio["initial_balance"]) * 100

    return {
        "balance": round(portfolio["balance"], 2),
        "equity": round(equity, 2),
        "initial_balance": portfolio["initial_balance"],
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round(total_pnl_pct, 2),
        "realized_pnl": round(realized_pnl, 2),
        "unrealized_pnl": round(total_unrealized_pnl, 2),
        "positions": positions_with_pnl,
        "trade_history": portfolio["trade_history"][-20:],  # Last 20 trades
    }


def open_trade(pair: str, trade_type: str, quantity: float) -> Dict:
    """Open a new simulated trade."""
    portfolio = _load_portfolio()

    df = get_forex_data(pair, period="1d", interval="1h")
    if df is None or len(df) == 0:
        return {"error": "Could not fetch current price for this pair."}

    current_price = float(df["Close"].iloc[-1])
    cost = current_price * quantity

    if trade_type == "BUY" and cost > portfolio["balance"]:
        return {"error": f"Insufficient balance. Need ${cost:.2f} but only have ${portfolio['balance']:.2f}"}

    position = {
        "id": portfolio["next_id"],
        "pair": pair,
        "type": trade_type,
        "entry_price": round(current_price, 5),
        "quantity": quantity,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    portfolio["positions"].append(position)
    portfolio["next_id"] += 1

    if trade_type == "BUY":
        portfolio["balance"] -= cost

    _save_portfolio(portfolio)

    return {
        "success": True,
        "message": f"Opened {trade_type} position: {quantity} units of {pair} at {current_price:.5f}",
        "position": position,
    }


def close_trade(position_id: int) -> Dict:
    """Close an existing simulated trade."""
    portfolio = _load_portfolio()

    position = None
    pos_index = None
    for i, pos in enumerate(portfolio["positions"]):
        if pos["id"] == position_id:
            position = pos
            pos_index = i
            break

    if position is None:
        return {"error": f"Position #{position_id} not found."}

    df = get_forex_data(position["pair"], period="1d", interval="1h")
    if df is None or len(df) == 0:
        return {"error": "Could not fetch current price."}

    close_price = float(df["Close"].iloc[-1])

    if position["type"] == "BUY":
        pnl = (close_price - position["entry_price"]) * position["quantity"]
        portfolio["balance"] += close_price * position["quantity"]
    else:
        pnl = (position["entry_price"] - close_price) * position["quantity"]
        portfolio["balance"] += pnl

    trade_record = {
        "id": position["id"],
        "pair": position["pair"],
        "type": position["type"],
        "entry_price": position["entry_price"],
        "exit_price": round(close_price, 5),
        "quantity": position["quantity"],
        "pnl": round(pnl, 2),
        "opened": position["timestamp"],
        "closed": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    portfolio["trade_history"].append(trade_record)
    portfolio["positions"].pop(pos_index)
    _save_portfolio(portfolio)

    return {
        "success": True,
        "message": f"Closed {position['type']} position on {position['pair']} at {close_price:.5f}. P&L: ${pnl:.2f}",
        "trade": trade_record,
    }


def reset_portfolio() -> Dict:
    """Reset portfolio to initial state."""
    portfolio = {
        "balance": INITIAL_BALANCE,
        "initial_balance": INITIAL_BALANCE,
        "positions": [],
        "trade_history": [],
        "next_id": 1,
    }
    _save_portfolio(portfolio)
    return {"success": True, "message": f"Portfolio reset to ${INITIAL_BALANCE:,.2f}"}
