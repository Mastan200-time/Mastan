#!/bin/bash
set -e

echo "🚀 Starting ForexPulse Trading Dashboard..."
echo "============================================"

# Navigate to project root
cd "$(dirname "$0")"

# Install backend dependencies if needed
echo "📦 Checking backend dependencies..."
cd backend
if [ -f requirements.txt ]; then
    python3 -m pip install -q -r requirements.txt 2>/dev/null || true
fi
cd ..

# Install frontend dependencies
echo "📦 Installing frontend dependencies..."
cd frontend
npm install --silent 2>/dev/null
cd ..

# Start backend
echo "🔧 Starting backend server on port 8100..."
cd backend
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8100 --reload &
BACKEND_PID=$!
cd ..

# Wait for backend to be ready
echo "⏳ Waiting for backend..."
for i in $(seq 1 30); do
    if curl -s http://localhost:8100/health > /dev/null 2>&1; then
        echo "✅ Backend is ready!"
        break
    fi
    sleep 1
done

# Start frontend
echo "🎨 Starting frontend on port 5173..."
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "============================================"
echo "✅ ForexPulse Dashboard is running!"
echo "   Frontend: http://localhost:5173"
echo "   Backend:  http://localhost:8100"
echo "   API Docs: http://localhost:8100/docs"
echo "============================================"

# Handle shutdown
cleanup() {
    echo ""
    echo "🛑 Shutting down..."
    kill $BACKEND_PID 2>/dev/null || true
    kill $FRONTEND_PID 2>/dev/null || true
    exit 0
}

trap cleanup SIGINT SIGTERM

# Wait for processes
wait
