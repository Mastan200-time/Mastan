from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class CandleData(BaseModel):
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: Optional[float] = 0


class IndicatorValues(BaseModel):
    rsi: Optional[List[Optional[float]]] = []
    macd_line: Optional[List[Optional[float]]] = []
    macd_signal: Optional[List[Optional[float]]] = []
    macd_histogram: Optional[List[Optional[float]]] = []
    sma_20: Optional[List[Optional[float]]] = []
    sma_50: Optional[List[Optional[float]]] = []
    ema_12: Optional[List[Optional[float]]] = []
    ema_26: Optional[List[Optional[float]]] = []


class Signal(BaseModel):
    type: str  # "BUY" or "SELL"
    pair: str
    price: float
    timestamp: str
    indicator: str
    strength: str  # "STRONG", "MODERATE", "WEAK"
    reason: str
    risk_warning: str


class PairData(BaseModel):
    pair: str
    candles: List[CandleData]
    indicators: IndicatorValues
    signals: List[Signal]
    current_price: float
    change_24h: float
    change_pct: float


class PortfolioTrade(BaseModel):
    id: Optional[int] = None
    pair: str
    type: str  # "BUY" or "SELL"
    entry_price: float
    quantity: float
    timestamp: Optional[str] = None


class PortfolioPosition(BaseModel):
    id: int
    pair: str
    type: str
    entry_price: float
    current_price: float
    quantity: float
    pnl: float
    pnl_pct: float
    timestamp: str


class PortfolioSummary(BaseModel):
    balance: float
    initial_balance: float
    total_pnl: float
    total_pnl_pct: float
    positions: List[PortfolioPosition]
    trade_history: List[dict]
