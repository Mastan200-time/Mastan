"""
Forex data and signals API router.
"""
from fastapi import APIRouter, Query
from typing import Optional
from app.services.forex_data import get_forex_data, get_all_pairs_summary, FOREX_PAIRS
from app.services.indicators import compute_all_indicators, generate_signals

router = APIRouter()


@router.get("/pairs")
async def list_pairs():
    """List all available forex pairs."""
    return {"pairs": list(FOREX_PAIRS.keys())}


@router.get("/pairs/summary")
async def pairs_summary():
    """Get summary data for all forex pairs."""
    return {"data": get_all_pairs_summary()}


@router.get("/pair/{pair_name}")
async def get_pair_data(
    pair_name: str,
    period: str = Query("1mo", description="Data period: 1d, 5d, 1mo, 3mo"),
    interval: str = Query("1h", description="Data interval: 1m, 5m, 15m, 1h, 1d"),
):
    """Get detailed data for a specific forex pair including candles, indicators, and signals."""
    pair = pair_name.replace("-", "/").upper()

    if pair not in FOREX_PAIRS:
        return {"error": f"Pair {pair} not found. Available: {list(FOREX_PAIRS.keys())}"}

    df = get_forex_data(pair, period=period, interval=interval)
    if df is None or len(df) == 0:
        return {"error": f"Could not fetch data for {pair}"}

    # Build candle data
    candles = []
    for _, row in df.iterrows():
        ts = row["Date"]
        candles.append({
            "timestamp": ts.strftime("%Y-%m-%d %H:%M") if hasattr(ts, "strftime") else str(ts),
            "open": round(float(row["Open"]), 5),
            "high": round(float(row["High"]), 5),
            "low": round(float(row["Low"]), 5),
            "close": round(float(row["Close"]), 5),
            "volume": float(row.get("Volume", 0)),
        })

    # Compute indicators
    indicators = compute_all_indicators(df)

    # Generate signals
    signals = generate_signals(df, pair)

    # Current price info
    current_price = float(df["Close"].iloc[-1])
    prev_price = float(df["Close"].iloc[-24]) if len(df) > 24 else float(df["Close"].iloc[0])
    change = current_price - prev_price
    change_pct = (change / prev_price) * 100

    return {
        "pair": pair,
        "candles": candles,
        "indicators": indicators,
        "signals": signals,
        "current_price": round(current_price, 5),
        "change_24h": round(change, 5),
        "change_pct": round(change_pct, 3),
    }
