import Tooltip from './Tooltip'

function IndicatorsPanel({ indicators, currentPrice }) {
  if (!indicators) return null

  const lastRSI = indicators.rsi?.filter(v => v !== null).slice(-1)[0]
  const lastMACD = indicators.macd_line?.filter(v => v !== null).slice(-1)[0]
  const lastSignal = indicators.macd_signal?.filter(v => v !== null).slice(-1)[0]
  const lastSMA20 = indicators.sma_20?.filter(v => v !== null).slice(-1)[0]
  const lastSMA50 = indicators.sma_50?.filter(v => v !== null).slice(-1)[0]

  const getRSIStatus = (val) => {
    if (!val) return { text: 'N/A', class: 'status-neutral' }
    if (val < 30) return { text: 'Oversold', class: 'status-bullish' }
    if (val > 70) return { text: 'Overbought', class: 'status-bearish' }
    return { text: 'Neutral', class: 'status-neutral' }
  }

  const getMACDStatus = (macd, signal) => {
    if (!macd || !signal) return { text: 'N/A', class: 'status-neutral' }
    if (macd > signal) return { text: 'Bullish', class: 'status-bullish' }
    return { text: 'Bearish', class: 'status-bearish' }
  }

  const getTrendStatus = (sma20, sma50) => {
    if (!sma20 || !sma50) return { text: 'N/A', class: 'status-neutral' }
    if (sma20 > sma50) return { text: 'Uptrend', class: 'status-bullish' }
    return { text: 'Downtrend', class: 'status-bearish' }
  }

  const getPriceVsSMA = (price, sma) => {
    if (!price || !sma) return { text: 'N/A', class: 'status-neutral' }
    if (price > sma) return { text: 'Above SMA', class: 'status-bullish' }
    return { text: 'Below SMA', class: 'status-bearish' }
  }

  const rsiStatus = getRSIStatus(lastRSI)
  const macdStatus = getMACDStatus(lastMACD, lastSignal)
  const trendStatus = getTrendStatus(lastSMA20, lastSMA50)
  const priceStatus = getPriceVsSMA(currentPrice, lastSMA20)

  return (
    <div className="indicators-panel">
      <div className="indicator-card">
        <div className="indicator-label">
          RSI (14) <Tooltip tooltipKey="RSI" />
        </div>
        <div className="indicator-value" style={{
          color: lastRSI < 30 ? 'var(--color-buy)' : lastRSI > 70 ? 'var(--color-sell)' : 'var(--text-primary)'
        }}>
          {lastRSI ? lastRSI.toFixed(1) : '—'}
        </div>
        <span className={`indicator-status ${rsiStatus.class}`}>{rsiStatus.text}</span>
      </div>

      <div className="indicator-card">
        <div className="indicator-label">
          MACD <Tooltip tooltipKey="MACD" />
        </div>
        <div className="indicator-value" style={{
          color: lastMACD > 0 ? 'var(--color-buy)' : 'var(--color-sell)'
        }}>
          {lastMACD ? lastMACD.toFixed(5) : '—'}
        </div>
        <span className={`indicator-status ${macdStatus.class}`}>{macdStatus.text}</span>
      </div>

      <div className="indicator-card">
        <div className="indicator-label">
          Trend (SMA) <Tooltip tooltipKey="SMA" />
        </div>
        <div className="indicator-value" style={{
          color: trendStatus.class === 'status-bullish' ? 'var(--color-buy)' : 'var(--color-sell)'
        }}>
          {trendStatus.text === 'N/A' ? '—' : trendStatus.text}
        </div>
        <span className={`indicator-status ${trendStatus.class}`}>
          {lastSMA20 ? `SMA20: ${lastSMA20.toFixed(4)}` : 'N/A'}
        </span>
      </div>

      <div className="indicator-card">
        <div className="indicator-label">
          Price vs SMA <Tooltip tooltipKey="EMA" />
        </div>
        <div className="indicator-value" style={{
          color: priceStatus.class === 'status-bullish' ? 'var(--color-buy)' : 'var(--color-sell)'
        }}>
          {priceStatus.text === 'N/A' ? '—' : priceStatus.text}
        </div>
        <span className={`indicator-status ${priceStatus.class}`}>
          {lastSMA50 ? `SMA50: ${lastSMA50.toFixed(4)}` : 'N/A'}
        </span>
      </div>
    </div>
  )
}

export default IndicatorsPanel
