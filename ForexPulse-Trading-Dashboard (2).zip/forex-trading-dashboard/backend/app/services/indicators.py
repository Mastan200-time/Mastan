"""
Technical indicators computation service.
Computes RSI, MACD, SMA, EMA and generates trading signals.
"""
import numpy as np
import pandas as pd
from typing import List, Optional, Dict
from datetime import datetime


def compute_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
    """Compute Relative Strength Index."""
    delta = prices.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)

    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()

    # Use exponential smoothing after initial SMA
    for i in range(period, len(prices)):
        avg_gain.iloc[i] = (avg_gain.iloc[i-1] * (period - 1) + gain.iloc[i]) / period
        avg_loss.iloc[i] = (avg_loss.iloc[i-1] * (period - 1) + loss.iloc[i]) / period

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def compute_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Dict[str, pd.Series]:
    """Compute MACD (Moving Average Convergence Divergence)."""
    ema_fast = prices.ewm(span=fast, adjust=False).mean()
    ema_slow = prices.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line

    return {
        "macd_line": macd_line,
        "signal_line": signal_line,
        "histogram": histogram,
    }


def compute_sma(prices: pd.Series, period: int) -> pd.Series:
    """Compute Simple Moving Average."""
    return prices.rolling(window=period, min_periods=1).mean()


def compute_ema(prices: pd.Series, period: int) -> pd.Series:
    """Compute Exponential Moving Average."""
    return prices.ewm(span=period, adjust=False).mean()


def compute_bollinger_bands(prices: pd.Series, period: int = 20, std_dev: float = 2.0) -> Dict[str, pd.Series]:
    """Compute Bollinger Bands."""
    sma = compute_sma(prices, period)
    std = prices.rolling(window=period).std()
    return {
        "upper": sma + (std * std_dev),
        "middle": sma,
        "lower": sma - (std * std_dev),
    }


def compute_all_indicators(df: pd.DataFrame) -> Dict:
    """Compute all technical indicators for a dataframe."""
    close = df["Close"]

    rsi = compute_rsi(close)
    macd = compute_macd(close)
    sma_20 = compute_sma(close, 20)
    sma_50 = compute_sma(close, 50)
    ema_12 = compute_ema(close, 12)
    ema_26 = compute_ema(close, 26)

    def safe_list(series):
        return [None if pd.isna(v) else round(float(v), 6) for v in series]

    return {
        "rsi": safe_list(rsi),
        "macd_line": safe_list(macd["macd_line"]),
        "macd_signal": safe_list(macd["signal_line"]),
        "macd_histogram": safe_list(macd["histogram"]),
        "sma_20": safe_list(sma_20),
        "sma_50": safe_list(sma_50),
        "ema_12": safe_list(ema_12),
        "ema_26": safe_list(ema_26),
    }


def generate_signals(df: pd.DataFrame, pair: str) -> List[Dict]:
    """Generate buy/sell signals based on multiple indicators."""
    signals = []
    close = df["Close"]
    n = len(close)

    if n < 50:
        return signals

    rsi = compute_rsi(close)
    macd = compute_macd(close)
    sma_20 = compute_sma(close, 20)
    sma_50 = compute_sma(close, 50)

    # Check last few candles for signals
    for i in range(max(50, n - 5), n):
        timestamp = df["Date"].iloc[i].strftime("%Y-%m-%d %H:%M") if hasattr(df["Date"].iloc[i], "strftime") else str(df["Date"].iloc[i])
        price = round(float(close.iloc[i]), 5)

        # RSI signals
        if not pd.isna(rsi.iloc[i]):
            rsi_val = rsi.iloc[i]
            if rsi_val < 30:
                strength = "STRONG" if rsi_val < 20 else "MODERATE"
                signals.append({
                    "type": "BUY",
                    "pair": pair,
                    "price": price,
                    "timestamp": timestamp,
                    "indicator": "RSI",
                    "strength": strength,
                    "reason": f"RSI is oversold at {rsi_val:.1f} (below 30), suggesting the pair may be undervalued and due for a bounce.",
                    "risk_warning": "⚠️ Oversold conditions can persist in strong downtrends. Always use a stop-loss and never risk more than 1-2% of your account on a single trade.",
                })
            elif rsi_val > 70:
                strength = "STRONG" if rsi_val > 80 else "MODERATE"
                signals.append({
                    "type": "SELL",
                    "pair": pair,
                    "price": price,
                    "timestamp": timestamp,
                    "indicator": "RSI",
                    "strength": strength,
                    "reason": f"RSI is overbought at {rsi_val:.1f} (above 70), suggesting the pair may be overvalued and due for a pullback.",
                    "risk_warning": "⚠️ Overbought conditions can persist in strong uptrends. Consider partial position sizing and always set a stop-loss.",
                })

        # MACD crossover signals
        if i > 0 and not pd.isna(macd["macd_line"].iloc[i]) and not pd.isna(macd["signal_line"].iloc[i]):
            macd_curr = macd["macd_line"].iloc[i]
            signal_curr = macd["signal_line"].iloc[i]
            macd_prev = macd["macd_line"].iloc[i-1]
            signal_prev = macd["signal_line"].iloc[i-1]

            if not pd.isna(macd_prev) and not pd.isna(signal_prev):
                if macd_prev <= signal_prev and macd_curr > signal_curr:
                    signals.append({
                        "type": "BUY",
                        "pair": pair,
                        "price": price,
                        "timestamp": timestamp,
                        "indicator": "MACD",
                        "strength": "MODERATE",
                        "reason": "MACD line crossed above the signal line (bullish crossover), indicating potential upward momentum.",
                        "risk_warning": "⚠️ MACD crossovers can produce false signals in ranging markets. Confirm with other indicators before entering a trade.",
                    })
                elif macd_prev >= signal_prev and macd_curr < signal_curr:
                    signals.append({
                        "type": "SELL",
                        "pair": pair,
                        "price": price,
                        "timestamp": timestamp,
                        "indicator": "MACD",
                        "strength": "MODERATE",
                        "reason": "MACD line crossed below the signal line (bearish crossover), indicating potential downward momentum.",
                        "risk_warning": "⚠️ MACD crossovers can lag behind price action. Use tight stop-losses and consider the overall trend direction.",
                    })

        # Moving Average crossover signals
        if not pd.isna(sma_20.iloc[i]) and not pd.isna(sma_50.iloc[i]) and i > 0:
            if not pd.isna(sma_20.iloc[i-1]) and not pd.isna(sma_50.iloc[i-1]):
                if sma_20.iloc[i-1] <= sma_50.iloc[i-1] and sma_20.iloc[i] > sma_50.iloc[i]:
                    signals.append({
                        "type": "BUY",
                        "pair": pair,
                        "price": price,
                        "timestamp": timestamp,
                        "indicator": "MA Crossover",
                        "strength": "STRONG",
                        "reason": "20-period SMA crossed above 50-period SMA (Golden Cross), a classic bullish signal indicating a potential trend change.",
                        "risk_warning": "⚠️ Moving average crossovers are lagging indicators. The move may have already started. Use proper position sizing.",
                    })
                elif sma_20.iloc[i-1] >= sma_50.iloc[i-1] and sma_20.iloc[i] < sma_50.iloc[i]:
                    signals.append({
                        "type": "SELL",
                        "pair": pair,
                        "price": price,
                        "timestamp": timestamp,
                        "indicator": "MA Crossover",
                        "strength": "STRONG",
                        "reason": "20-period SMA crossed below 50-period SMA (Death Cross), a classic bearish signal indicating a potential trend reversal.",
                        "risk_warning": "⚠️ This is a lagging signal. The downtrend may already be underway. Never chase a trade — wait for confirmation.",
                    })

    # Deduplicate and keep most recent signals
    seen = set()
    unique_signals = []
    for s in reversed(signals):
        key = f"{s['type']}_{s['indicator']}_{s['timestamp']}"
        if key not in seen:
            seen.add(key)
            unique_signals.append(s)

    return list(reversed(unique_signals[-10:]))  # Keep last 10 signals
