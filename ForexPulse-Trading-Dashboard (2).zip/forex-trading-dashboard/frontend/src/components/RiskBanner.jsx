import { useState } from 'react'
import Tooltip from './Tooltip'
import { RISK_DISCLAIMERS } from '../utils/tooltips'

function RiskBanner() {
  const [dismissed, setDismissed] = useState(false)

  if (dismissed) return null

  return (
    <div className="risk-banner">
      <span className="risk-icon">⚠️</span>
      <div className="risk-text">
        <strong>Educational Tool — Not Financial Advice</strong> <Tooltip tooltipKey="RISK_GENERAL" />
        <br />
        {RISK_DISCLAIMERS[0]} {RISK_DISCLAIMERS[2]}
      </div>
      <button
        onClick={() => setDismissed(true)}
        style={{
          background: 'none',
          border: 'none',
          color: 'var(--text-muted)',
          cursor: 'pointer',
          fontSize: '1rem',
          padding: '4px',
          flexShrink: 0,
        }}
      >
        ✕
      </button>
    </div>
  )
}

export default RiskBanner
