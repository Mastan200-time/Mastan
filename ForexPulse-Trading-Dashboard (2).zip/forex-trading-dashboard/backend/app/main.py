from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import forex, portfolio

app = FastAPI(
    title="Forex Trading Signal Dashboard API",
    description="Real-time forex data, technical indicators, trading signals, and simulated portfolio management",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(forex.router, prefix="/api", tags=["Forex Data"])
app.include_router(portfolio.router, prefix="/api", tags=["Portfolio"])


@app.get("/")
async def root():
    return {"message": "Forex Trading Signal Dashboard API", "docs": "/docs"}


@app.get("/health")
async def health():
    return {"status": "healthy"}
