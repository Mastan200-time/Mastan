import { useState, useRef, useCallback } from 'react'
import { getTooltip } from '../utils/tooltips'

function Tooltip({ tooltipKey }) {
  const [visible, setVisible] = useState(false)
  const [position, setPosition] = useState({ top: 0, left: 0 })
  const triggerRef = useRef(null)

  const tooltip = getTooltip(tooltipKey)
  if (!tooltip) return null

  const showTooltip = useCallback(() => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect()
      setPosition({
        top: rect.bottom + 8,
        left: Math.min(rect.left, window.innerWidth - 380),
      })
    }
    setVisible(true)
  }, [])

  return (
    <>
      <span
        ref={triggerRef}
        className="tooltip-trigger"
        onMouseEnter={showTooltip}
        onMouseLeave={() => setVisible(false)}
        onClick={(e) => { e.stopPropagation(); setVisible(!visible) }}
      >
        ?
      </span>
      {visible && (
        <div
          className="tooltip-popup"
          style={{ top: position.top, left: position.left }}
          onMouseEnter={() => setVisible(true)}
          onMouseLeave={() => setVisible(false)}
        >
          <h4>{tooltip.title}</h4>
          <div className="tooltip-short">{tooltip.short}</div>
          <div className="tooltip-detail">{tooltip.detail}</div>
          {tooltip.beginner && (
            <div className="tooltip-beginner">{tooltip.beginner}</div>
          )}
        </div>
      )}
    </>
  )
}

export default Tooltip
