function Header({ activeTab, onTabChange }) {
  const tabs = [
    { id: 'dashboard', label: '📊 Dashboard' },
    { id: 'portfolio', label: '💼 Portfolio' },
  ]

  return (
    <header className="header">
      <div className="header-brand">
        <span className="logo">📈</span>
        <div>
          <h1>ForexPulse</h1>
          <span className="subtitle">Trading Signal Dashboard</span>
        </div>
      </div>

      <nav className="header-nav">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={activeTab === tab.id ? 'active' : ''}
            onClick={() => onTabChange(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      <div className="header-status">
        <div className="live-indicator">
          <span className="live-dot"></span>
          LIVE DATA
        </div>
      </div>
    </header>
  )
}

export default Header
