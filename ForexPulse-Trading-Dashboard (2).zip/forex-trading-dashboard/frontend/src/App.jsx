import { useState, useEffect, useCallback } from 'react'
import { fetchPairsSummary, fetchPairData, executeTrade } from './services/api'
import Header from './components/Header'
import Footer from './components/Footer'
import PairCard from './components/PairCard'
import PriceChart from './components/PriceChart'
import IndicatorsPanel from './components/IndicatorsPanel'
import SignalsPanel from './components/SignalsPanel'
import Portfolio from './components/Portfolio'
import RiskBanner from './components/RiskBanner'
import Tooltip from './components/Tooltip'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [pairs, setPairs] = useState([])
  const [selectedPair, setSelectedPair] = useState('EUR/USD')
  const [pairData, setPairData] = useState(null)
  const [period, setPeriod] = useState('1mo')
  const [loading, setLoading] = useState(true)
  const [chartLoading, setChartLoading] = useState(false)
  const [newSignalPopup, setNewSignalPopup] = useState(null)
  const [lastSignalCount, setLastSignalCount] = useState(0)

  // Fetch all pairs summary
  const loadPairs = useCallback(async () => {
    try {
      const res = await fetchPairsSummary()
      if (res.data?.data) {
        setPairs(res.data.data)
      }
    } catch (err) {
      console.error('Failed to load pairs:', err)
    }
  }, [])

  // Fetch detailed data for selected pair
  const loadPairData = useCallback(async (pair, p) => {
    setChartLoading(true)
    try {
      const res = await fetchPairData(pair, p)
      if (res.data && !res.data.error) {
        setPairData(res.data)

        // Check for new signals and show popup
        const newSignals = res.data.signals || []
        if (newSignals.length > lastSignalCount && lastSignalCount > 0) {
          const latestSignal = newSignals[newSignals.length - 1]
          setNewSignalPopup(latestSignal)
          setTimeout(() => setNewSignalPopup(null), 8000)
        }
        setLastSignalCount(newSignals.length)
      }
    } catch (err) {
      console.error('Failed to load pair data:', err)
    } finally {
      setChartLoading(false)
      setLoading(false)
    }
  }, [lastSignalCount])

  // Initial load
  useEffect(() => {
    loadPairs()
    loadPairData(selectedPair, period)
  }, [])

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      loadPairs()
      loadPairData(selectedPair, period)
    }, 30000)
    return () => clearInterval(interval)
  }, [selectedPair, period, loadPairs, loadPairData])

  const handlePairSelect = (pair) => {
    setSelectedPair(pair)
    loadPairData(pair, period)
  }

  const handlePeriodChange = (p) => {
    setPeriod(p)
    loadPairData(selectedPair, p)
  }

  const handleSignalTrade = async (signal) => {
    try {
      await executeTrade(signal.pair, signal.type, 1000)
    } catch (err) {
      console.error('Trade from signal failed:', err)
    }
  }

  const periods = [
    { value: '1d', label: '1D' },
    { value: '5d', label: '5D' },
    { value: '1mo', label: '1M' },
    { value: '3mo', label: '3M' },
  ]

  if (loading) {
    return (
      <div className="app-container">
        <Header activeTab={activeTab} onTabChange={setActiveTab} />
        <div className="main-content">
          <div className="loading-container">
            <div className="spinner"></div>
            <p>Loading market data...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="app-container">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="main-content">
        {activeTab === 'dashboard' ? (
          <>
            <RiskBanner />

            {/* Pairs Overview */}
            <div className="pairs-grid">
              {pairs.map(pair => (
                <PairCard
                  key={pair.pair}
                  pair={pair}
                  selected={pair.pair === selectedPair}
                  onClick={handlePairSelect}
                />
              ))}
            </div>

            {/* Period Selector */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 500 }}>Timeframe:</span>
              <div className="chart-controls">
                {periods.map(p => (
                  <button
                    key={p.value}
                    className={period === p.value ? 'active' : ''}
                    onClick={() => handlePeriodChange(p.value)}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
              <Tooltip tooltipKey="LEVERAGE" />
            </div>

            {/* Main Dashboard Grid */}
            <div className="dashboard-grid">
              <div className="chart-section">
                {/* Price Chart */}
                {chartLoading ? (
                  <div className="chart-container">
                    <div className="loading-container">
                      <div className="spinner"></div>
                      <p>Loading chart...</p>
                    </div>
                  </div>
                ) : (
                  <PriceChart
                    candles={pairData?.candles}
                    indicators={pairData?.indicators}
                    pair={selectedPair}
                  />
                )}

                {/* Indicators */}
                <IndicatorsPanel
                  indicators={pairData?.indicators}
                  currentPrice={pairData?.current_price}
                />
              </div>

              <div className="sidebar-section">
                {/* Signals */}
                <SignalsPanel
                  signals={pairData?.signals}
                  onTrade={handleSignalTrade}
                />

                {/* Quick Info */}
                <div className="card" style={{ background: 'rgba(59, 130, 246, 0.05)' }}>
                  <div className="card-title" style={{ marginBottom: 10 }}>
                    <span>📖</span> How to Read Signals
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                    <p style={{ marginBottom: 8 }}>
                      <span style={{ color: 'var(--color-buy)' }}>🟢 BUY signals</span> suggest the price may go up. 
                      <span style={{ color: 'var(--color-sell)' }}> 🔴 SELL signals</span> suggest it may go down.
                    </p>
                    <p style={{ marginBottom: 8 }}>
                      <strong>Signal strength</strong> indicates confidence: 💪 Strong signals have more indicator confirmation than 🤏 Weak ones.
                    </p>
                    <p>
                      ⚠️ <strong>Never trade on a single signal.</strong> Click any signal to see its full analysis and risk warning.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <Portfolio pairs={pairs.map(p => p.pair)} />
        )}
      </main>

      <Footer />

      {/* New Signal Toast Popup */}
      {newSignalPopup && (
        <div
          style={{
            position: 'fixed',
            top: 80,
            right: 20,
            zIndex: 999,
            background: 'var(--bg-secondary)',
            border: `1px solid ${newSignalPopup.type === 'BUY' ? 'var(--color-buy-border)' : 'var(--color-sell-border)'}`,
            borderLeft: `4px solid ${newSignalPopup.type === 'BUY' ? 'var(--color-buy)' : 'var(--color-sell)'}`,
            borderRadius: 'var(--radius-md)',
            padding: '14px 18px',
            maxWidth: 340,
            boxShadow: 'var(--shadow-lg)',
            animation: 'slideUp 0.3s ease',
            cursor: 'pointer',
          }}
          onClick={() => setNewSignalPopup(null)}
        >
          <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: 4 }}>
            {newSignalPopup.type === 'BUY' ? '🟢' : '🔴'} New {newSignalPopup.type} Signal!
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>
            {newSignalPopup.pair} — {newSignalPopup.indicator} at {newSignalPopup.price}
          </div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: 4 }}>
            Click to dismiss
          </div>
        </div>
      )}
    </div>
  )
}

export default App
