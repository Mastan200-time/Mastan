"""
Portfolio management API router.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.portfolio import get_portfolio_summary, open_trade, close_trade, reset_portfolio

router = APIRouter()


class TradeRequest(BaseModel):
    pair: str
    type: str  # "BUY" or "SELL"
    quantity: float


@router.get("/portfolio")
async def get_portfolio():
    """Get current portfolio summary."""
    return get_portfolio_summary()


@router.post("/portfolio/trade")
async def execute_trade(trade: TradeRequest):
    """Open a new simulated trade."""
    return open_trade(trade.pair, trade.type.upper(), trade.quantity)


@router.post("/portfolio/close/{position_id}")
async def close_position(position_id: int):
    """Close an existing position."""
    return close_trade(position_id)


@router.post("/portfolio/reset")
async def reset():
    """Reset portfolio to initial balance."""
    return reset_portfolio()
