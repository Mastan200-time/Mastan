import { useEffect, useRef, useState } from 'react'

function PriceChart({ candles, indicators, pair }) {
  const chartContainerRef = useRef(null)
  const chartRef = useRef(null)
  const [chartType, setChartType] = useState('candlestick')
  const [showSMA20, setShowSMA20] = useState(true)
  const [showSMA50, setShowSMA50] = useState(true)

  useEffect(() => {
    if (!candles || candles.length === 0 || !chartContainerRef.current) return

    let chart = null
    let cleanup = () => {}

    const initChart = async () => {
      try {
        const LWC = await import('lightweight-charts')
        const createChart = LWC.createChart

        // Clear previous chart
        if (chartRef.current) {
          chartRef.current.remove()
          chartRef.current = null
        }
        chartContainerRef.current.innerHTML = ''

        chart = createChart(chartContainerRef.current, {
          width: chartContainerRef.current.clientWidth,
          height: 370,
          layout: {
            background: { color: '#1a1f2e' },
            textColor: '#9ca3af',
            fontSize: 11,
            fontFamily: "'Inter', sans-serif",
          },
          grid: {
            vertLines: { color: 'rgba(42, 46, 57, 0.5)' },
            horzLines: { color: 'rgba(42, 46, 57, 0.5)' },
          },
          crosshair: {
            mode: 0,
            vertLine: { color: '#3b82f6', width: 1, style: 2, labelBackgroundColor: '#3b82f6' },
            horzLine: { color: '#3b82f6', width: 1, style: 2, labelBackgroundColor: '#3b82f6' },
          },
          rightPriceScale: {
            borderColor: '#1f2937',
            scaleMargins: { top: 0.1, bottom: 0.1 },
          },
          timeScale: {
            borderColor: '#1f2937',
            timeVisible: true,
            secondsVisible: false,
          },
        })

        chartRef.current = chart

        // Parse candle data
        const parsedCandles = candles.map(c => {
          const d = new Date(c.timestamp)
          return {
            time: Math.floor(d.getTime() / 1000),
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close,
          }
        }).filter((c, i, arr) => i === 0 || c.time > arr[i-1].time)

        if (parsedCandles.length === 0) return

        // Main price series
        if (chartType === 'candlestick') {
          const candleSeries = chart.addCandlestickSeries({
            upColor: '#10b981',
            downColor: '#ef4444',
            borderUpColor: '#10b981',
            borderDownColor: '#ef4444',
            wickUpColor: '#10b981',
            wickDownColor: '#ef4444',
          })
          candleSeries.setData(parsedCandles)
        } else {
          const lineSeries = chart.addLineSeries({
            color: '#3b82f6',
            lineWidth: 2,
          })
          lineSeries.setData(parsedCandles.map(c => ({ time: c.time, value: c.close })))
        }

        // SMA 20 overlay
        if (showSMA20 && indicators?.sma_20) {
          const sma20Data = indicators.sma_20
            .map((v, i) => v !== null ? { time: parsedCandles[i]?.time, value: v } : null)
            .filter(d => d && d.time)
          
          if (sma20Data.length > 0) {
            const sma20Series = chart.addLineSeries({
              color: '#f59e0b',
              lineWidth: 1,
              lineStyle: 0,
              title: 'SMA 20',
            })
            const uniqueSma20 = sma20Data.filter((d, i, arr) => i === 0 || d.time > arr[i-1].time)
            if (uniqueSma20.length > 0) sma20Series.setData(uniqueSma20)
          }
        }

        // SMA 50 overlay
        if (showSMA50 && indicators?.sma_50) {
          const sma50Data = indicators.sma_50
            .map((v, i) => v !== null ? { time: parsedCandles[i]?.time, value: v } : null)
            .filter(d => d && d.time)
          
          if (sma50Data.length > 0) {
            const sma50Series = chart.addLineSeries({
              color: '#8b5cf6',
              lineWidth: 1,
              lineStyle: 0,
              title: 'SMA 50',
            })
            const uniqueSma50 = sma50Data.filter((d, i, arr) => i === 0 || d.time > arr[i-1].time)
            if (uniqueSma50.length > 0) sma50Series.setData(uniqueSma50)
          }
        }

        chart.timeScale().fitContent()

        // Resize handler
        const handleResize = () => {
          if (chart && chartContainerRef.current) {
            chart.applyOptions({ width: chartContainerRef.current.clientWidth })
          }
        }
        window.addEventListener('resize', handleResize)
        cleanup = () => {
          window.removeEventListener('resize', handleResize)
          if (chart) {
            chart.remove()
            chartRef.current = null
          }
        }
      } catch (err) {
        console.error('Chart init error:', err)
      }
    }

    initChart()
    return () => cleanup()
  }, [candles, indicators, chartType, showSMA20, showSMA50])

  return (
    <div className="chart-container">
      <div className="card-header">
        <div className="card-title">
          <span>📊</span> {pair} Price Chart
        </div>
        <div className="chart-controls">
          <button
            className={chartType === 'candlestick' ? 'active' : ''}
            onClick={() => setChartType('candlestick')}
          >
            Candles
          </button>
          <button
            className={chartType === 'line' ? 'active' : ''}
            onClick={() => setChartType('line')}
          >
            Line
          </button>
          <button
            className={showSMA20 ? 'active' : ''}
            onClick={() => setShowSMA20(!showSMA20)}
            style={{ borderColor: showSMA20 ? '#f59e0b' : undefined }}
          >
            SMA 20
          </button>
          <button
            className={showSMA50 ? 'active' : ''}
            onClick={() => setShowSMA50(!showSMA50)}
            style={{ borderColor: showSMA50 ? '#8b5cf6' : undefined }}
          >
            SMA 50
          </button>
        </div>
      </div>
      <div className="chart-wrapper" ref={chartContainerRef} />
    </div>
  )
}

export default PriceChart
