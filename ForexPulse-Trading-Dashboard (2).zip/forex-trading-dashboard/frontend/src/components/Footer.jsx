import { RISK_DISCLAIMERS } from '../utils/tooltips'

function Footer() {
  return (
    <footer className="footer">
      <p className="disclaimer">
        ⚠️ {RISK_DISCLAIMERS[0]}
      </p>
      <p>
        {RISK_DISCLAIMERS[2]} • {RISK_DISCLAIMERS[3]}
      </p>
      <p style={{ marginTop: 6 }}>
        ForexPulse Dashboard © 2026 — Built for learning. Trade responsibly.
      </p>
    </footer>
  )
}

export default Footer
