import { useState, useEffect, useCallback } from 'react'
import { fetchPortfolio, executeTrade, closePosition, resetPortfolio } from '../services/api'
import Tooltip from './Tooltip'
import { RISK_DISCLAIMERS } from '../utils/tooltips'

function Portfolio({ pairs }) {
  const [portfolio, setPortfolio] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tradePair, setTradePair] = useState('EUR/USD')
  const [tradeQty, setTradeQty] = useState(1000)
  const [message, setMessage] = useState(null)

  const loadPortfolio = useCallback(async () => {
    try {
      const res = await fetchPortfolio()
      setPortfolio(res.data)
    } catch (err) {
      console.error('Portfolio fetch error:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadPortfolio()
    const interval = setInterval(loadPortfolio, 15000)
    return () => clearInterval(interval)
  }, [loadPortfolio])

  const handleTrade = async (type) => {
    try {
      const res = await executeTrade(tradePair, type, tradeQty)
      if (res.data.error) {
        setMessage({ type: 'error', text: res.data.error })
      } else {
        setMessage({ type: 'success', text: res.data.message })
        loadPortfolio()
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Trade failed. Please try again.' })
    }
    setTimeout(() => setMessage(null), 5000)
  }

  const handleClose = async (posId) => {
    try {
      const res = await closePosition(posId)
      if (res.data.error) {
        setMessage({ type: 'error', text: res.data.error })
      } else {
        setMessage({ type: 'success', text: res.data.message })
        loadPortfolio()
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to close position.' })
    }
    setTimeout(() => setMessage(null), 5000)
  }

  const handleReset = async () => {
    if (!window.confirm('Reset portfolio to $10,000? All positions and history will be cleared.')) return
    try {
      await resetPortfolio()
      loadPortfolio()
      setMessage({ type: 'success', text: 'Portfolio reset to $10,000.00' })
    } catch (err) {
      setMessage({ type: 'error', text: 'Reset failed.' })
    }
    setTimeout(() => setMessage(null), 5000)
  }

  if (loading) {
    return <div className="loading-container"><div className="spinner"></div><p>Loading portfolio...</p></div>
  }

  return (
    <div>
      {/* Risk Banner */}
      <div className="risk-banner">
        <span className="risk-icon">⚠️</span>
        <div className="risk-text">
          <strong>Simulated Trading Only</strong> — This portfolio uses virtual money ($10,000). 
          No real money is at risk. {RISK_DISCLAIMERS[0]}
        </div>
      </div>

      {/* Message */}
      {message && (
        <div style={{
          padding: '10px 16px',
          borderRadius: 'var(--radius-md)',
          marginBottom: 16,
          background: message.type === 'success' ? 'var(--color-buy-bg)' : 'var(--color-sell-bg)',
          color: message.type === 'success' ? 'var(--color-buy)' : 'var(--color-sell)',
          border: `1px solid ${message.type === 'success' ? 'var(--color-buy-border)' : 'var(--color-sell-border)'}`,
          fontSize: '0.85rem',
        }}>
          {message.type === 'success' ? '✅' : '❌'} {message.text}
        </div>
      )}

      {/* Portfolio Stats */}
      <div className="portfolio-stats">
        <div className="stat-card">
          <div className="stat-label">Balance <Tooltip tooltipKey="PORTFOLIO" /></div>
          <div className="stat-value">${portfolio?.balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Equity</div>
          <div className="stat-value">${portfolio?.equity?.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total P&L <Tooltip tooltipKey="PNL" /></div>
          <div className={`stat-value ${portfolio?.total_pnl >= 0 ? 'positive' : 'negative'}`}>
            {portfolio?.total_pnl >= 0 ? '+' : ''}${portfolio?.total_pnl?.toFixed(2)}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Return %</div>
          <div className={`stat-value ${portfolio?.total_pnl_pct >= 0 ? 'positive' : 'negative'}`}>
            {portfolio?.total_pnl_pct >= 0 ? '+' : ''}{portfolio?.total_pnl_pct?.toFixed(2)}%
          </div>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="chart-section">
          {/* Open Positions */}
          <div className="card">
            <div className="card-header">
              <div className="card-title"><span>📂</span> Open Positions ({portfolio?.positions?.length || 0})</div>
            </div>
            {portfolio?.positions?.length > 0 ? (
              <div style={{ overflowX: 'auto' }}>
                <table className="positions-table">
                  <thead>
                    <tr>
                      <th>Pair</th>
                      <th>Type</th>
                      <th>Entry</th>
                      <th>Current</th>
                      <th>Qty</th>
                      <th>P&L</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {portfolio.positions.map(pos => (
                      <tr key={pos.id}>
                        <td style={{ fontWeight: 600 }}>{pos.pair}</td>
                        <td>
                          <span className={`signal-badge ${pos.type.toLowerCase()}`}>
                            {pos.type}
                          </span>
                        </td>
                        <td>{pos.entry_price}</td>
                        <td>{pos.current_price}</td>
                        <td>{pos.quantity.toLocaleString()}</td>
                        <td style={{ color: pos.pnl >= 0 ? 'var(--color-buy)' : 'var(--color-sell)', fontWeight: 600 }}>
                          {pos.pnl >= 0 ? '+' : ''}${pos.pnl.toFixed(2)} ({pos.pnl_pct.toFixed(2)}%)
                        </td>
                        <td>
                          <button className="close-btn" onClick={() => handleClose(pos.id)}>
                            Close
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-icon">📭</div>
                <p>No open positions. Use the trade form to open your first simulated trade!</p>
              </div>
            )}
          </div>

          {/* Trade History */}
          <div className="card">
            <div className="card-header">
              <div className="card-title"><span>📜</span> Trade History</div>
            </div>
            {portfolio?.trade_history?.length > 0 ? (
              <div style={{ overflowX: 'auto' }}>
                <table className="positions-table">
                  <thead>
                    <tr>
                      <th>Pair</th>
                      <th>Type</th>
                      <th>Entry</th>
                      <th>Exit</th>
                      <th>Qty</th>
                      <th>P&L</th>
                      <th>Closed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...portfolio.trade_history].reverse().map((trade, idx) => (
                      <tr key={idx}>
                        <td style={{ fontWeight: 600 }}>{trade.pair}</td>
                        <td>
                          <span className={`signal-badge ${trade.type.toLowerCase()}`}>
                            {trade.type}
                          </span>
                        </td>
                        <td>{trade.entry_price}</td>
                        <td>{trade.exit_price}</td>
                        <td>{trade.quantity?.toLocaleString()}</td>
                        <td style={{ color: trade.pnl >= 0 ? 'var(--color-buy)' : 'var(--color-sell)', fontWeight: 600 }}>
                          {trade.pnl >= 0 ? '+' : ''}${trade.pnl?.toFixed(2)}
                        </td>
                        <td style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{trade.closed}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-icon">📋</div>
                <p>No trade history yet. Close a position to see it here.</p>
              </div>
            )}
          </div>
        </div>

        <div className="sidebar-section">
          {/* Trade Form */}
          <div className="trade-form">
            <h3>
              <span>🔄</span> New Trade
              <Tooltip tooltipKey="STOP_LOSS" />
            </h3>

            <div className="form-group">
              <label>Currency Pair</label>
              <select value={tradePair} onChange={e => setTradePair(e.target.value)}>
                {(pairs || ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'USD/CHF', 'NZD/USD', 'EUR/GBP']).map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Quantity (units) <Tooltip tooltipKey="PIP" /></label>
              <input
                type="number"
                value={tradeQty}
                onChange={e => setTradeQty(Number(e.target.value))}
                min={100}
                step={100}
              />
            </div>

            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: 8 }}>
              💡 1,000 units = micro lot • 10,000 = mini lot • 100,000 = standard lot
            </div>

            <div className="trade-buttons">
              <button className="btn-buy" onClick={() => handleTrade('BUY')}>
                ▲ BUY (Long)
              </button>
              <button className="btn-sell" onClick={() => handleTrade('SELL')}>
                ▼ SELL (Short)
              </button>
            </div>
          </div>

          {/* Risk Info */}
          <div className="card" style={{ background: 'rgba(245, 158, 11, 0.05)' }}>
            <div className="card-title" style={{ marginBottom: 10 }}>
              <span>📚</span> Beginner Tips
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              <p style={{ marginBottom: 8 }}>
                <strong style={{ color: 'var(--color-warning)' }}>🎯 Risk Management:</strong> Never risk more than 1-2% of your account on a single trade. With $10,000, that means max $100-$200 risk per trade.
              </p>
              <p style={{ marginBottom: 8 }}>
                <strong style={{ color: 'var(--accent-blue)' }}>📊 Multiple Confirmations:</strong> Don't trade on a single indicator. Look for 2-3 indicators agreeing before entering a position.
              </p>
              <p>
                <strong style={{ color: 'var(--accent-purple)' }}>🧠 Psychology:</strong> Stick to your plan. Don't let emotions drive your trading decisions. This simulator helps you practice discipline!
              </p>
            </div>
          </div>

          {/* Reset Button */}
          <button
            onClick={handleReset}
            style={{
              width: '100%',
              padding: '10px',
              background: 'var(--bg-card)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              fontSize: '0.8rem',
              fontFamily: 'var(--font-sans)',
            }}
          >
            🔄 Reset Portfolio to $10,000
          </button>
        </div>
      </div>
    </div>
  )
}

export default Portfolio
