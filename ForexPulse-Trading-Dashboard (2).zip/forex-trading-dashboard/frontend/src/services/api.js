import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data || error.message)
    return Promise.reject(error)
  }
)

export const fetchPairs = () => api.get('/pairs')
export const fetchPairsSummary = () => api.get('/pairs/summary')
export const fetchPairData = (pair, period = '1mo', interval = '1h') =>
  api.get(`/pair/${pair.replace('/', '-')}`, { params: { period, interval } })
export const fetchPortfolio = () => api.get('/portfolio')
export const executeTrade = (pair, type, quantity) =>
  api.post('/portfolio/trade', { pair, type, quantity })
export const closePosition = (positionId) =>
  api.post(`/portfolio/close/${positionId}`)
export const resetPortfolio = () => api.post('/portfolio/reset')

export default api
