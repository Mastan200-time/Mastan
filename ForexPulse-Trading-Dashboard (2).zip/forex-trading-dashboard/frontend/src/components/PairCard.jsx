function PairCard({ pair, selected, onClick }) {
  const isPositive = pair.change_pct >= 0

  return (
    <div
      className={`pair-card ${selected ? 'selected' : ''}`}
      onClick={() => onClick(pair.pair)}
    >
      <div className="pair-name">{pair.pair}</div>
      <div className="pair-price" style={{ color: isPositive ? 'var(--color-buy)' : 'var(--color-sell)' }}>
        {pair.price?.toFixed(pair.pair.includes('JPY') ? 3 : 5)}
      </div>
      <div className={`pair-change ${isPositive ? 'positive' : 'negative'}`}>
        {isPositive ? '▲' : '▼'} {Math.abs(pair.change_pct).toFixed(3)}%
        <span style={{ marginLeft: 6, color: 'var(--text-muted)' }}>
          ({isPositive ? '+' : ''}{pair.change?.toFixed(5)})
        </span>
      </div>
    </div>
  )
}

export default PairCard
