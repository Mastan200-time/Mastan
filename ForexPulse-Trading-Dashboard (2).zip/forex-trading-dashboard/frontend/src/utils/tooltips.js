/**
 * Educational tooltips for beginner forex traders.
 * Each tooltip explains a concept in simple, friendly language.
 */

export const TOOLTIPS = {
  // Indicator tooltips
  RSI: {
    title: "RSI (Relative Strength Index)",
    short: "Measures if a currency pair is overbought or oversold",
    detail: "RSI ranges from 0 to 100. Below 30 means the pair might be oversold (potential buy opportunity). Above 70 means it might be overbought (potential sell opportunity). Think of it like a speedometer — extreme readings suggest the price might reverse direction.",
    beginner: "🎓 Beginner tip: RSI works best in ranging markets. In strong trends, RSI can stay overbought/oversold for extended periods."
  },
  MACD: {
    title: "MACD (Moving Average Convergence Divergence)",
    short: "Shows the relationship between two moving averages",
    detail: "MACD consists of the MACD line (difference between 12 and 26 period EMAs), a signal line (9-period EMA of MACD), and a histogram. When the MACD line crosses above the signal line, it's a bullish signal. When it crosses below, it's bearish.",
    beginner: "🎓 Beginner tip: Look for MACD crossovers that align with the overall trend direction for higher probability trades."
  },
  SMA: {
    title: "SMA (Simple Moving Average)",
    short: "Average price over a specific number of periods",
    detail: "SMA smooths out price data to show the overall trend direction. The 20-period SMA shows short-term trend, while the 50-period SMA shows medium-term trend. When the shorter SMA crosses above the longer one, it's called a 'Golden Cross' (bullish).",
    beginner: "🎓 Beginner tip: Moving averages are lagging indicators — they confirm trends rather than predict them. Use them with other indicators."
  },
  EMA: {
    title: "EMA (Exponential Moving Average)",
    short: "Like SMA but gives more weight to recent prices",
    detail: "EMA reacts faster to price changes than SMA because it weights recent data more heavily. This makes it better for catching trend changes early, but also more prone to false signals.",
    beginner: "🎓 Beginner tip: EMAs are great for identifying trend direction. Price above EMA = uptrend, price below EMA = downtrend."
  },

  // Trading concept tooltips
  BUY_SIGNAL: {
    title: "Buy Signal",
    short: "An indicator suggests the price may go up",
    detail: "A buy signal means technical indicators suggest the currency pair might increase in value. This is NOT a guarantee — it's a suggestion based on historical patterns. Always do your own analysis and use risk management.",
    beginner: "🎓 Beginner tip: Never act on a single signal. Look for confirmation from multiple indicators before entering a trade."
  },
  SELL_SIGNAL: {
    title: "Sell Signal",
    short: "An indicator suggests the price may go down",
    detail: "A sell signal means technical indicators suggest the currency pair might decrease in value. Like buy signals, these are probabilistic — not certain. Always use stop-losses to protect your capital.",
    beginner: "🎓 Beginner tip: In forex, you can profit from falling prices too (by selling/shorting). But always manage your risk!"
  },
  SPREAD: {
    title: "Spread",
    short: "The difference between buy and sell price",
    detail: "The spread is the cost of trading — it's the difference between the bid (sell) price and the ask (buy) price. Lower spreads mean lower trading costs. Major pairs like EUR/USD typically have the tightest spreads.",
    beginner: "🎓 Beginner tip: Always factor in the spread when calculating potential profits. It's the broker's fee for executing your trade."
  },
  LEVERAGE: {
    title: "Leverage",
    short: "Trading with borrowed money to amplify gains (and losses!)",
    detail: "Leverage lets you control a large position with a small amount of money. For example, 100:1 leverage means $100 controls $10,000. While this amplifies profits, it equally amplifies losses. This is why forex trading is risky.",
    beginner: "⚠️ WARNING: Leverage is the #1 reason beginners lose money in forex. Start with low or no leverage until you're consistently profitable."
  },
  STOP_LOSS: {
    title: "Stop Loss",
    short: "An order that automatically closes your trade at a set loss level",
    detail: "A stop-loss order automatically closes your position when the price reaches a certain level, limiting your loss. Professional traders ALWAYS use stop-losses. A common rule is to never risk more than 1-2% of your account on a single trade.",
    beginner: "🎓 Beginner tip: Set your stop-loss BEFORE entering a trade. Never move it further away from your entry — that's a recipe for disaster."
  },
  PIP: {
    title: "Pip",
    short: "The smallest price movement in forex (usually 0.0001)",
    detail: "A pip (Percentage in Point) is the smallest standard price movement. For most pairs, 1 pip = 0.0001. For JPY pairs, 1 pip = 0.01. Pips are used to measure price changes and calculate profits/losses.",
    beginner: "🎓 Beginner tip: In a standard lot (100,000 units), 1 pip = roughly $10 for USD pairs. In a mini lot (10,000), 1 pip ≈ $1."
  },

  // Portfolio tooltips
  PORTFOLIO: {
    title: "Simulated Portfolio",
    short: "Practice trading with virtual money — no real risk!",
    detail: "This portfolio uses virtual money ($10,000) so you can practice trading without risking real funds. Track your performance, test strategies, and build confidence before trading with real money.",
    beginner: "🎓 Beginner tip: Treat this like real money! Develop good habits now — they'll carry over when you trade for real."
  },
  PNL: {
    title: "P&L (Profit & Loss)",
    short: "How much you've gained or lost on your trades",
    detail: "P&L shows your trading performance. Unrealized P&L is from open positions (not yet locked in). Realized P&L is from closed trades. Green = profit, Red = loss.",
    beginner: "🎓 Beginner tip: Focus on your win rate AND your risk-reward ratio. You can be profitable even with a 40% win rate if your winners are bigger than your losers."
  },

  // Risk warnings
  RISK_GENERAL: {
    title: "⚠️ Risk Warning",
    short: "Forex trading involves significant risk of loss",
    detail: "Trading foreign exchange carries a high level of risk and may not be suitable for all investors. The high degree of leverage can work against you as well as for you. You should carefully consider your investment objectives, level of experience, and risk appetite.",
    beginner: "📊 Statistics show that 70-80% of retail forex traders lose money. This dashboard is for EDUCATIONAL purposes. Practice with simulated money first!"
  }
}

export const getTooltip = (key) => TOOLTIPS[key] || null

export const RISK_DISCLAIMERS = [
  "This dashboard is for educational purposes only. It does not constitute financial advice.",
  "Past performance of technical indicators does not guarantee future results.",
  "Forex trading involves substantial risk of loss. Never trade with money you can't afford to lose.",
  "All signals are generated by algorithms and should not be the sole basis for trading decisions.",
  "The simulated portfolio uses virtual money. Real trading results may differ significantly.",
  "Always consult a qualified financial advisor before making investment decisions.",
]
