"""
Forex data service - fetches real-time and historical forex data.
Uses yfinance for reliable forex pair data.
"""
import yfinance as yf
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json
import time
import threading

# Cache for forex data to avoid excessive API calls
_cache: Dict[str, dict] = {}
_cache_lock = threading.Lock()
CACHE_TTL = 30  # seconds

FOREX_PAIRS = {
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "USD/JPY": "USDJPY=X",
    "AUD/USD": "AUDUSD=X",
    "USD/CAD": "USDCAD=X",
    "USD/CHF": "USDCHF=X",
    "NZD/USD": "NZDUSD=X",
    "EUR/GBP": "EURGBP=X",
}


def get_forex_data(pair: str, period: str = "1mo", interval: str = "1h") -> Optional[pd.DataFrame]:
    """Fetch forex data from yfinance with caching."""
    cache_key = f"{pair}_{period}_{interval}"

    with _cache_lock:
        if cache_key in _cache:
            cached = _cache[cache_key]
            if time.time() - cached["time"] < CACHE_TTL:
                return cached["data"]

    ticker_symbol = FOREX_PAIRS.get(pair)
    if not ticker_symbol:
        return None

    try:
        ticker = yf.Ticker(ticker_symbol)
        df = ticker.history(period=period, interval=interval)

        if df.empty:
            return None

        df = df.reset_index()
        if "Datetime" in df.columns:
            df.rename(columns={"Datetime": "Date"}, inplace=True)

        df["Date"] = pd.to_datetime(df["Date"])
        df = df.sort_values("Date").reset_index(drop=True)

        with _cache_lock:
            _cache[cache_key] = {"data": df, "time": time.time()}

        return df

    except Exception as e:
        print(f"Error fetching data for {pair}: {e}")
        return _generate_simulated_data(pair, period, interval)


def _generate_simulated_data(pair: str, period: str, interval: str) -> pd.DataFrame:
    """Generate realistic simulated forex data as fallback."""
    base_prices = {
        "EUR/USD": 1.0850, "GBP/USD": 1.2650, "USD/JPY": 151.50,
        "AUD/USD": 0.6550, "USD/CAD": 1.3650, "USD/CHF": 0.8850,
        "NZD/USD": 0.6050, "EUR/GBP": 0.8580,
    }

    base = base_prices.get(pair, 1.0)
    volatility = 0.0003 if "JPY" not in pair else 0.03

    num_points = {"1d": 24, "5d": 120, "1mo": 500, "3mo": 1500}.get(period, 500)

    np.random.seed(hash(pair + str(int(time.time()) // 60)) % (2**31))

    dates = pd.date_range(end=datetime.now(), periods=num_points, freq="1h")
    returns = np.random.normal(0, volatility, num_points)
    prices = base * np.exp(np.cumsum(returns))

    df = pd.DataFrame({
        "Date": dates,
        "Open": prices * (1 + np.random.uniform(-0.0002, 0.0002, num_points)),
        "High": prices * (1 + np.abs(np.random.normal(0, 0.0005, num_points))),
        "Low": prices * (1 - np.abs(np.random.normal(0, 0.0005, num_points))),
        "Close": prices,
        "Volume": np.random.randint(1000, 50000, num_points),
    })

    return df


def get_all_pairs_summary() -> List[dict]:
    """Get summary data for all forex pairs."""
    summaries = []
    for pair, symbol in FOREX_PAIRS.items():
        try:
            df = get_forex_data(pair, period="5d", interval="1h")
            if df is not None and len(df) > 1:
                current = df["Close"].iloc[-1]
                prev_day = df["Close"].iloc[-24] if len(df) > 24 else df["Close"].iloc[0]
                change = current - prev_day
                change_pct = (change / prev_day) * 100

                summaries.append({
                    "pair": pair,
                    "price": round(float(current), 5),
                    "change": round(float(change), 5),
                    "change_pct": round(float(change_pct), 3),
                    "high_24h": round(float(df["High"].tail(24).max()), 5),
                    "low_24h": round(float(df["Low"].tail(24).min()), 5),
                })
        except Exception as e:
            print(f"Error getting summary for {pair}: {e}")

    return summaries
