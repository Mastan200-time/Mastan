import { useState } from 'react'
import Tooltip from './Tooltip'

function SignalPopup({ signal, onClose, onTrade }) {
  return (
    <div className="signal-popup-overlay" onClick={onClose}>
      <div className={`signal-popup ${signal.type.toLowerCase()}`} onClick={e => e.stopPropagation()}>
        <h2>
          {signal.type === 'BUY' ? '🟢' : '🔴'}
          {signal.type} Signal — {signal.pair}
        </h2>

        <div className="popup-detail">
          <label>Indicator</label>
          <div className="value">{signal.indicator}</div>
        </div>

        <div className="popup-detail">
          <label>Signal Strength</label>
          <div className="value">
            {signal.strength === 'STRONG' ? '💪 Strong' : signal.strength === 'MODERATE' ? '👍 Moderate' : '🤏 Weak'}
          </div>
        </div>

        <div className="popup-detail">
          <label>Price at Signal</label>
          <div className="value" style={{ fontFamily: 'var(--font-mono)', fontSize: '1.1rem' }}>
            {signal.price}
          </div>
        </div>

        <div className="popup-detail">
          <label>Analysis</label>
          <div className="value" style={{ fontSize: '0.85rem', lineHeight: 1.5 }}>
            {signal.reason}
          </div>
        </div>

        <div className="signal-risk" style={{ marginTop: 12 }}>
          {signal.risk_warning}
        </div>

        <div className="popup-actions">
          <button className="btn-secondary" onClick={onClose}>Dismiss</button>
          <button
            className={signal.type === 'BUY' ? 'btn-buy' : 'btn-sell'}
            onClick={() => { onTrade(signal); onClose() }}
          >
            Sim {signal.type} Trade
          </button>
        </div>
      </div>
    </div>
  )
}

function SignalsPanel({ signals, onTrade }) {
  const [selectedSignal, setSelectedSignal] = useState(null)

  if (!signals || signals.length === 0) {
    return (
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <span>🔔</span> Trading Signals
            <Tooltip tooltipKey="BUY_SIGNAL" />
          </div>
        </div>
        <div className="empty-state">
          <div className="empty-icon">📡</div>
          <p>No signals detected for this pair right now. Signals are generated when indicators reach key levels.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <span>🔔</span> Trading Signals ({signals.length})
          </div>
        </div>
        <div className="signals-panel">
          {signals.map((signal, idx) => (
            <div
              key={idx}
              className={`signal-item ${signal.type.toLowerCase()}`}
              onClick={() => setSelectedSignal(signal)}
            >
              <div className="signal-header">
                <span className={`signal-badge ${signal.type.toLowerCase()}`}>
                  {signal.type === 'BUY' ? '▲ BUY' : '▼ SELL'}
                </span>
                <span className="signal-strength">
                  {signal.strength === 'STRONG' ? '💪 Strong' : signal.strength === 'MODERATE' ? '👍 Moderate' : '🤏 Weak'}
                </span>
              </div>
              <div className="signal-indicator">{signal.indicator}</div>
              <div className="signal-reason">{signal.reason}</div>
              <div className="signal-risk">{signal.risk_warning}</div>
              <div className="signal-meta">
                <span>{signal.pair} @ {signal.price}</span>
                <span>{signal.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedSignal && (
        <SignalPopup
          signal={selectedSignal}
          onClose={() => setSelectedSignal(null)}
          onTrade={onTrade}
        />
      )}
    </>
  )
}

export default SignalsPanel
