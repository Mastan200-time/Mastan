# 📈 ForexPulse — Forex Trading Signal Dashboard

A beginner-friendly forex trading signal web dashboard with live market data, technical indicator-based buy/sell alerts, educational tooltips, risk warnings, and a simulated portfolio tracker.

**⚠️ This is an educational tool only — not financial advice. Never trade with money you can't afford to lose.**

---

## ✨ Features

**Live Market Dashboard**
- Real-time prices for 8 major forex pairs (EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD, USD/CHF, NZD/USD, EUR/GBP)
- Professional candlestick and line charts with SMA 20/50 overlays
- Multiple timeframes: 1 Day, 5 Days, 1 Month, 3 Months
- Auto-refreshes every 30 seconds

**Technical Indicators**
- RSI (Relative Strength Index) — overbought/oversold detection
- MACD (Moving Average Convergence Divergence) — momentum shifts
- SMA Crossovers (Golden Cross / Death Cross) — trend direction
- Color-coded bullish/bearish status cards

**Buy/Sell Signal Alerts**
- Automatically generated when indicators hit key levels
- Detailed popup with analysis, signal strength, and risk warning
- Toast notifications for new signals in real-time
- One-click simulated trade from any signal

**Simulated Portfolio Tracker**
- $10,000 virtual balance for risk-free practice
- Open BUY (long) or SELL (short) positions
- Live P&L tracking on all open positions
- Full trade history with entry/exit prices

**Beginner-Friendly**
- Educational tooltips explaining every concept (hover the ? icons)
- Risk warnings on every signal and throughout the UI
- "How to Read Signals" guide built into the sidebar
- Beginner tips on risk management and trading psychology

---

## 🛠️ Prerequisites

Before you start, make sure you have these installed on your computer:

1. **Python 3.10+** — Download from [python.org](https://www.python.org/downloads/)
2. **Node.js 18+** — Download from [nodejs.org](https://nodejs.org/)

To verify they're installed, open a terminal and run:
```bash
python3 --version    # Should show 3.10 or higher
node --version       # Should show 18 or higher
npm --version        # Should show 8 or higher
```

---

## 🚀 Quick Start (One Command)

### On Mac / Linux:
```bash
cd forex-trading-dashboard
chmod +x start.sh
./start.sh
```

### On Windows:
Open two terminal windows:

**Terminal 1 — Backend:**
```bash
cd forex-trading-dashboard/backend
pip install fastapi uvicorn yfinance pandas numpy
python -m uvicorn app.main:app --host 0.0.0.0 --port 8100 --reload
```

**Terminal 2 — Frontend:**
```bash
cd forex-trading-dashboard/frontend
npm install
npm run dev
```

### Open the Dashboard:
Once both servers are running, open your browser and go to:

👉 **http://localhost:5173**

The backend API docs are available at: http://localhost:8100/docs

---

## 📁 Project Structure

```
forex-trading-dashboard/
├── start.sh                    # One-command startup script
├── README.md                   # This file
│
├── backend/                    # Python FastAPI backend
│   ├── main.py                 # Entry point
│   ├── requirements.txt        # Python dependencies
│   └── app/
│       ├── main.py             # FastAPI app configuration
│       ├── models/
│       │   └── schemas.py      # Data models
│       ├── routers/
│       │   ├── forex.py        # Forex data & signals API
│       │   └── portfolio.py    # Portfolio management API
│       └── services/
│           ├── forex_data.py   # Market data fetching (yfinance)
│           ├── indicators.py   # Technical indicator calculations
│           └── portfolio.py    # Simulated portfolio logic
│
└── frontend/                   # React frontend
    ├── package.json            # Node.js dependencies
    ├── vite.config.js          # Vite configuration
    ├── index.html              # HTML entry point
    └── src/
        ├── main.jsx            # React entry point
        ├── App.jsx             # Main application component
        ├── services/
        │   └── api.js          # API client
        ├── components/
        │   ├── Header.jsx      # Navigation header
        │   ├── Footer.jsx      # Footer with disclaimers
        │   ├── PairCard.jsx    # Forex pair price card
        │   ├── PriceChart.jsx  # Candlestick/line chart
        │   ├── IndicatorsPanel.jsx  # Technical indicators
        │   ├── SignalsPanel.jsx     # Buy/sell signals
        │   ├── Portfolio.jsx        # Portfolio tracker
        │   ├── RiskBanner.jsx       # Risk warning banner
        │   └── Tooltip.jsx          # Educational tooltips
        ├── utils/
        │   └── tooltips.js     # Tooltip content & risk disclaimers
        └── styles/
            └── global.css      # Dark trading theme styles
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/pairs` | List all available forex pairs |
| GET | `/api/pairs/summary` | Get summary with live prices for all pairs |
| GET | `/api/pair/{pair}` | Get detailed data: candles, indicators, signals |
| GET | `/api/portfolio` | Get portfolio summary with live P&L |
| POST | `/api/portfolio/trade` | Open a new simulated trade |
| POST | `/api/portfolio/close/{id}` | Close an open position |
| POST | `/api/portfolio/reset` | Reset portfolio to $10,000 |

---

## 🧰 Tech Stack

- **Frontend:** React 18, Vite, Lightweight Charts (TradingView), Axios
- **Backend:** Python, FastAPI, yfinance, NumPy, Pandas
- **Styling:** Custom CSS with dark trading theme

---

## ⚠️ Disclaimer

This dashboard is for **educational purposes only**. It does not constitute financial advice. Forex trading involves substantial risk of loss. Never trade with money you can't afford to lose. All signals are generated by algorithms and should not be the sole basis for trading decisions. Always consult a qualified financial advisor before making investment decisions.

---

Built with ❤️ for learning. Trade responsibly.
